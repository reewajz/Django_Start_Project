import os
import django
from faker import Faker

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'djStart.settings')
django.setup()
fake = Faker()
