from django.apps import AppConfig


class DjappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'DJapp'
